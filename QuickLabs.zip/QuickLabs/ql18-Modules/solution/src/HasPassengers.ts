export default interface HasPassengers {

    readonly passengerSeats: number;
    makeStop(numberOn: number, numberOff: number): void;

}