let quote = [`I`, `am`, `your`, `friend`];
console.log(quote);