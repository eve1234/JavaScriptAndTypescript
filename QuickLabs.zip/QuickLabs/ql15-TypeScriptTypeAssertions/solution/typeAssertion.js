var something = "1234";
console.log(something == 1234);
console.log(something === 1234);
console.log(something >= 1000);
console.log(something.length);
console.log(something === 1234);
console.log(something >= 1000);
console.log(something.length);
