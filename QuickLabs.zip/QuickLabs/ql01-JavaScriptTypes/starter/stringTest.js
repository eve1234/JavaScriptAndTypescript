let stringTest = `I am the very model of a modern major general`;
let indexOfM;
console.log(indexOfM);