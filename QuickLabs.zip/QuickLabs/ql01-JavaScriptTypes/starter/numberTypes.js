let numTest;
console.log(numTest);

let twoDecimalPlaces;
console.log(twoDecimalPlaces);

