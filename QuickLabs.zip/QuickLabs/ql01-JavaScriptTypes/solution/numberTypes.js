let numTest = 45.324568;
console.log(numTest);

let twoDecimalPoints = numTest.toFixed(2);
console.log(twoDecimalPoints);
console.log(typeof twoDecimalPoints);
